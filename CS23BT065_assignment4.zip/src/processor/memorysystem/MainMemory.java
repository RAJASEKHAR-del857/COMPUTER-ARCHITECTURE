
package processor.memorysystem;

public class MainMemory {
	private int[] memory;
	
	// Memory size defined as 64KB (65536 addresses)
	private static final int MEMORY_SIZE = 65536;

	// Constructor initializes memory
	public MainMemory() {
		memory = new int[MEMORY_SIZE];

		// Optional: Initialize memory with a default value (e.g., -1)
		for (int i = 0; i < MEMORY_SIZE; i++) {
			memory[i] = 0;
		}
	}

	/**
	 * Fetches the word stored at a specific memory address.
	 * @param address The memory address (must be within bounds).
	 * @return The word stored at the address.
	 * @throws IllegalArgumentException if address is out of bounds.
	 */
	public int getWord(int address) {
		if (address < 0 || address >= MEMORY_SIZE) {
			throw new IllegalArgumentException("Invalid memory access: Address " + address + " is out of bounds.");
		}
		return memory[address];
	}

	/**
	 * Stores a value at a specific memory address.
	 * @param address The memory address (must be within bounds).
	 * @param value The value to store.
	 * @throws IllegalArgumentException if address is out of bounds.
	 */
	public void setWord(int address, int value) {
		if (address < 0 || address >= MEMORY_SIZE) {
			throw new IllegalArgumentException("Invalid memory access: Address " + address + " is out of bounds.");
		}
		memory[address] = value;
	}

	/**
	 * Returns a formatted string representation of memory contents in a given range.
	 * @param startingAddress The starting memory address.
	 * @param endingAddress The ending memory address.
	 * @return A string representing memory contents.
	 * @throws IllegalArgumentException if addresses are out of bounds or invalid.
	 */
	public String getContentsAsString(int startingAddress, int endingAddress) {
		if (startingAddress < 0 || endingAddress >= MEMORY_SIZE || startingAddress > endingAddress) {
			throw new IllegalArgumentException("Invalid memory range: [" + startingAddress + " - " + endingAddress + "]");
		}

		if (startingAddress == endingAddress) {
			return "";
		}

		StringBuilder sb = new StringBuilder();
		sb.append("\nMain Memory Contents:\n\n");
		for (int i = startingAddress; i <= endingAddress; i++) {
			sb.append(String.format("Address: 0x%04X -> Value: %d\n", i, memory[i])); // Hex address format
		}
		sb.append("\n");
		return sb.toString();
	}
}


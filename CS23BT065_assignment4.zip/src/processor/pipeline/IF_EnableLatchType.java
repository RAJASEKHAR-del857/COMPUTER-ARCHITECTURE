
package processor.pipeline;

// This class represents the latch that controls whether the Instruction Fetch (IF) stage is enabled.
public class IF_EnableLatchType {
	
	// Boolean flag to indicate if the IF stage is enabled
	boolean IF_enable;
	
	// Constructor: Initializes the IF stage as enabled by default
	public IF_EnableLatchType() {
		IF_enable = true;
	}

	// Getter method to check if the IF stage is enabled
	public boolean isIF_enable() {
		return IF_enable;
	}

	// Setter method to enable or disable the IF stage
	public void setIF_enable(boolean iF_enable) {
		IF_enable = iF_enable;
	}
}


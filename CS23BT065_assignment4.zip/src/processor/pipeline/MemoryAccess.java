
package processor.pipeline;

import processor.Processor;

public class MemoryAccess {
	// References to the processor and latch objects
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;

	// Constructor: Initializes references to processor and pipeline latches
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch) {
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}

	// Executes the memory access (MA) stage
	public void performMA() {
		// Check if the Memory Access stage is enabled
		if (EX_MA_Latch.isMA_enable()) {
			// Fetch values from the EX_MA latch
			int op1 = EX_MA_Latch.getOperand1();  // First operand
			int op2 = EX_MA_Latch.getOperand2();  // Second operand
			int aluResult = EX_MA_Latch.getaluResult();  // Result from ALU
			String opcode = EX_MA_Latch.getopcode();  // Opcode of instruction
			int destOperand = EX_MA_Latch.getDestOperand();  // Destination operand (register)
			int ldResult = 0;  // Variable to store load instruction result

			System.out.println("MA: " + opcode);  // Debugging output

			// Check if instruction is "end" (opcode 11101)
			if (opcode.equals("11101")) {
				// Forward opcode and disable MA stage
				MA_RW_Latch.setopcode(opcode);
				EX_MA_Latch.setMA_enable(false); // Closing MA stage after "end"
				MA_RW_Latch.setRW_enable(true);
			}
			
			// Check if instruction is "store" (opcode 10111)
			if (opcode.equals("10111")) {  
				int mar = aluResult;  // Memory Address Register
				int mdr = op1;  // Memory Data Register

				// Store the value at the computed memory address
				containingProcessor.getMainMemory().setWord(mar, mdr);
			}

			// Check if instruction is "load" (opcode 10110)
			if (opcode.equals("10110")) {  
				int mar = aluResult;  // Memory Address Register
				ldResult = containingProcessor.getMainMemory().getWord(mar);  // Load data from memory
			}

			// Update values in MA_RW latch to pass to the next stage
			MA_RW_Latch.setDestOperand(destOperand);
			MA_RW_Latch.setaluResult(aluResult);
			MA_RW_Latch.setldResult(ldResult);
			MA_RW_Latch.setopcode(opcode);

			// Disable MA stage and enable RW stage
			EX_MA_Latch.setMA_enable(false);
			MA_RW_Latch.setRW_enable(true);
		}
	}
}


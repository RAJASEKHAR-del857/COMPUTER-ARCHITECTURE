package processor.pipeline;

public class OF_EX_LatchType {
	
	// Flag to indicate whether the Execute (EX) stage is enabled
	boolean EX_enable;
	
	// Variables to store instruction details
	int BranchTarget;   // Address for branch instructions (currently unused)
	int op1, op2;       // Operands for ALU operations
	int imm;            // Immediate value for instructions using immediate operands
	int destOperand;    // Destination register for storing results
	String opcode;      // Opcode representing the instruction type
	
	// Constructor: Initializes the latch with EX stage disabled
	public OF_EX_LatchType()
	{
		EX_enable = false;
	}

	// Getter and Setter for EX stage enable flag
	public boolean isEX_enable() {
		return EX_enable;
	}

	public void setEX_enable(boolean eX_enable) {
		EX_enable = eX_enable;
	}

	// Getter and Setter for Operand 1
	public int getOperand1() {
		return op1;
	}	

	public void setOperand1(int op1) {
		this.op1 = op1;
	}

	// Getter and Setter for Operand 2
	public int getOperand2() {
		return op2;
	}	

	public void setOperand2(int op2) {
		this.op2 = op2;
	}

	// Getter and Setter for Immediate value
	public int getImm() {
		return imm;
	}	

	public void setImm(int imm) {
		this.imm = imm;
	}

	// Getter and Setter for Opcode
	public String getOpcode() {
		return opcode;
	}
	public void setOpcode(String opcode) {
		this.opcode = opcode;
	}

	// Getter and Setter for Destination Operand (register where result is stored)
	public int getDestOperand(){
		return this.destOperand;
	}
	public void setDestOperand(int destOperand){
		this.destOperand = destOperand;
	}
}

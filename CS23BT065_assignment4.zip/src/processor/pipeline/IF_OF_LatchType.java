package processor.pipeline;

// This class represents the latch between the Instruction Fetch (IF) and Operand Fetch (OF) stages.
public class IF_OF_LatchType {
	
	// Boolean flag to indicate if the OF stage is enabled
	boolean OF_enable;

	// Stores the instruction fetched from memory
	int instruction;

	// Array to handle data interlocks (to track dependencies between registers)
	int[] LockArr = new int[32];

	// Control lock to manage hazards related to control flow (e.g., branch instructions)
	int cLock;
	
	// Constructor: Initializes the latch with default values
	public IF_OF_LatchType() {
		OF_enable = false;  // Operand Fetch is disabled initially
		
		// Initialize the data interlock array (default values set to 0)
		LockArr = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		
		cLock = 0;  // No control interlock initially
	}

	// Getter method to check if the OF stage is enabled
	public boolean isOF_enable() {
		return OF_enable;
	}

	// Setter method to enable or disable the OF stage
	public void setOF_enable(boolean oF_enable) {
		OF_enable = oF_enable;
	}

	// Getter method to retrieve the fetched instruction
	public int getInstruction() {
		return instruction;
	}

	// Setter method to store the fetched instruction
	public void setInstruction(int instruction) {
		this.instruction = instruction;
	}

	// Getter method for retrieving the data interlocks array
	public int[] getDataInterlocks() {
		return LockArr;
	}

	// Setter method for updating the data interlocks array
	public void setDataInterlocks(int[] arr) {
		this.LockArr = arr;
	}

	// Getter method for retrieving the control lock value
	public int getControlLock() {
		return cLock;
	}

	// Setter method for updating the control lock value
	public void setControlLock(int cLock) {
		this.cLock = cLock;
	}
}


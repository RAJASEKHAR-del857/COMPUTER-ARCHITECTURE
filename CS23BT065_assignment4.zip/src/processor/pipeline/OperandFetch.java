package processor.pipeline;

// import generic.Instruction;
import generic.Statistics;
import processor.Processor;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	Statistics stats;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}

	public static String toSigned(String s){
		String inverted="";
		for(int i=0;i<s.length();i++){    //1's complement
			if(s.charAt(i)=='0')
				inverted+="1";
			else
				inverted+="0";
		}
		String result="";
		int carry=1;
		for(int i=s.length()-1;i>=0;i--){    //adding 1 to binary.
			if(inverted.charAt(i)=='1' && carry==1){
				result="0"+result;
			}
			else if(inverted.charAt(i)=='0' && carry==1){
				result="1"+result;
				carry=0;
			}
			else{
				result=inverted.charAt(i)+result;
			}
		}
		return result;
	}

	public static String SignedBinary(int val) {
		String s = "";
	
		if (val < 0) {
			s = Integer.toBinaryString(-val);	 // Get binary representation of positive value
		} else {
			s = Integer.toBinaryString(val);
		}
	
		// Pad the binary representation with leading zeros to ensure it's 32 bits long
		while (s.length() < 32) {
			s = "0" + s;
		}
		if (val<0){
		return toSigned(s);
		}
		else{
			return s;
		}
	}
	
	String instructionType(String opcode){
		if(Integer.parseInt(opcode,2)==24){
			return "RI";
		}
		else if(Integer.parseInt(opcode,2)<=20 && Integer.parseInt(opcode,2)%2==0){
			return "R3";
		}
		else if(opcode.equals("11101")){
			return "end";
		}
		else{
			return "R2I";
		}
	}

	//for data interlocking
	int[] dataInterlocking(int rd, int[] arr){
		
		if(rd!=-1){
			arr[rd]+=1;   // >=1 : register locked, == 0 : register unlocked
			// > 1 if two subsequent instructions works on same rd
			System.out.println(rd +" " +  arr[rd]);
		}
		return arr;
	}

	public void performOF()
	{
		// two bubbles are introduced for a RAW hazard
		// one bubbles are introduced for control hazard: when branch inst is in OF, IF receives a bubble.
		if(IF_OF_Latch.isOF_enable())
		{
			int instruction=IF_OF_Latch.getInstruction();
			String encoded=SignedBinary(instruction);
			String imm;
			int op1=0, op2=0, destOperand=0;
			String opcode=encoded.substring(0,5);

			//for data interlocking
			int[] LockArr=IF_OF_Latch.getDataInterlocks();

			System.out.println("OF:"+opcode);


			if(instructionType(opcode).equals("RI")){     //jmp 
				String rd=encoded.substring(5,10);
				imm=encoded.substring(22);
				op1=containingProcessor.getRegisterFile().getValue(Integer.parseInt(rd));

				// for control interlocks
				int controlLock=IF_OF_Latch.getControlLock();
				//ControlLock == 0 : occurrance of branch instruction
				//ControlLock == 1 : introduce a bubble in the pipeline
				// same idea used in other type of branch instructions
				if(controlLock==0){                            
					IF_OF_Latch.setControlLock(1);
					int PC=containingProcessor.getRegisterFile().getProgramCounter();
					containingProcessor.getRegisterFile().setProgramCounter(PC-1);
				}
				if(controlLock==1){
					IF_OF_Latch.setControlLock(0);
					IF_OF_Latch.setOF_enable(true);
					OF_EX_Latch.setEX_enable(false);	//locking EX stage mirrors the effect of bubble in EX stage
					Statistics.setNumberOfControlHazard(Statistics.getNumberOfControlHazard()+1); //updating stats
					return;				
				}
				
			}
			else if(instructionType(opcode).equals("end")){ //check for end instruction
				OF_EX_Latch.setOpcode(opcode);         
				IF_OF_Latch.setOF_enable(false);     // if true close OF stage
				OF_EX_Latch.setEX_enable(true);
				return;
			}
			else if(instructionType(opcode).equals("R2I")){
				String rs1=encoded.substring(5,10);
				String rd=encoded.substring(10,15);
				imm=encoded.substring(15);
				destOperand=Integer.parseInt(rd,2);

				//for data interlocking
				if(opcode.equals("10111") && LockArr[destOperand]==1){  // data hazard for store instruction
					IF_OF_Latch.setOF_enable(true);                             // always true to constantly check for unlocking of registers
					OF_EX_Latch.setEX_enable(false);                            //locking EX stage mirrors the effect of bubble in EX stage
					int PC=containingProcessor.getRegisterFile().getProgramCounter();     	  
					containingProcessor.getRegisterFile().setProgramCounter(PC-1);        // make sure IF_OF_Latch does not get updated with new values
					Statistics.setNumberOfOFstalls(Statistics.getNumberOfOFstalls()+1);   //update our stats
					return;
				}
				
				//data hazard for branch instructions
				if((opcode.equals("11001") || opcode.equals("11010") || opcode.equals("11011") || opcode.equals("11100"))
					&& (LockArr[destOperand]==1 || LockArr[Integer.parseInt(rs1,2)]==1)){    
					IF_OF_Latch.setOF_enable(true);                            // always true to constantly check for unlocking of registers 
					OF_EX_Latch.setEX_enable(false);                           //locking EX stage mirrors the effect of bubble in EX stage 
					int PC=containingProcessor.getRegisterFile().getProgramCounter();
					containingProcessor.getRegisterFile().setProgramCounter(PC-1);       // make sure IF_OF_Latch does not get updated with new values
					Statistics.setNumberOfOFstalls(Statistics.getNumberOfOFstalls()+1);   //update our stats
					return;
				}
				// data hazard - simple R2I type instructions
				if(LockArr[Integer.parseInt(rs1,2)]==1){
					IF_OF_Latch.setOF_enable(true);
					OF_EX_Latch.setEX_enable(false);
					int PC=containingProcessor.getRegisterFile().getProgramCounter();
					containingProcessor.getRegisterFile().setProgramCounter(PC-1);
					Statistics.setNumberOfOFstalls(Statistics.getNumberOfOFstalls()+1);
					return;
				}

				if(!(opcode.equals("10111") || opcode.equals("11001") || opcode.equals("11010") || opcode.equals("11011") || opcode.equals("11100"))){
					LockArr=dataInterlocking(destOperand,LockArr);
				}
				
				//for control Interlocking
				if(opcode.equals("11001") || opcode.equals("11010") || opcode.equals("11011") || opcode.equals("11100")){
					int controlLock=IF_OF_Latch.getControlLock();
					if(controlLock==0){
						IF_OF_Latch.setControlLock(1);
						int PC=containingProcessor.getRegisterFile().getProgramCounter();
						containingProcessor.getRegisterFile().setProgramCounter(PC-1);
					}
					if(controlLock==1){
						IF_OF_Latch.setControlLock(0);
						IF_OF_Latch.setOF_enable(true);
						OF_EX_Latch.setEX_enable(false);	
						Statistics.setNumberOfControlHazard(Statistics.getNumberOfControlHazard()+1);
						return;		
					}
				}

				op1=containingProcessor.getRegisterFile().getValue(Integer.parseInt(rs1,2));
				op2=containingProcessor.getRegisterFile().getValue(Integer.parseInt(rd,2));

			}
			else{ 
				String rs1=encoded.substring(5, 10);
				String rs2=encoded.substring(10, 15);
				String rd=encoded.substring(15, 20);
				imm=encoded.substring(20);
				destOperand=Integer.parseInt(rd,2);
				
				//for data interlocking
				if(LockArr[Integer.parseInt(rs1,2)]==1 || LockArr[Integer.parseInt(rs2,2)]==1){
					IF_OF_Latch.setOF_enable(true);
					OF_EX_Latch.setEX_enable(false);
					int PC=containingProcessor.getRegisterFile().getProgramCounter();
					containingProcessor.getRegisterFile().setProgramCounter(PC-1);
					Statistics.setNumberOfOFstalls(Statistics.getNumberOfOFstalls()+1);
					return;
				}
				LockArr=dataInterlocking(destOperand, LockArr); // always lock the destoperand in R3 type

				op1=containingProcessor.getRegisterFile().getValue(Integer.parseInt(rs1,2));
				op2=containingProcessor.getRegisterFile().getValue(Integer.parseInt(rs2,2));
			}

			int immediate=0;
			if(imm.startsWith("1")){
				imm=toSigned(imm);
				immediate=-Integer.parseInt(imm,2);
			}
			else{
				immediate=Integer.parseInt(imm,2);
			}
			
			OF_EX_Latch.setDestOperand(destOperand);
			OF_EX_Latch.setOperand1(op1);
			OF_EX_Latch.setOperand2(op2);
			OF_EX_Latch.setImm(immediate);
			OF_EX_Latch.setOpcode(opcode);

			//for data interlocking
			IF_OF_Latch.setDataInterlocks(LockArr);

			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
		}
	}

}

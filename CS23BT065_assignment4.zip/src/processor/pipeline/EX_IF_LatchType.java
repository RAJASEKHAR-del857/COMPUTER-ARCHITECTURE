
package processor.pipeline;

// This class represents the latch between the Execute (EX) stage and the Instruction Fetch (IF) stage.
public class EX_IF_LatchType {

	// A boolean flag to indicate whether the IF stage should be enabled
	boolean IF_enable;
	
	// Constructor: Initializes the latch with IF stage disabled by default
	public EX_IF_LatchType() {
		IF_enable = false;
	}

	// Getter method to check if IF stage is enabled
	public boolean isIF_enable() {
		return IF_enable;
	}

	// Setter method to enable or disable the IF stage
	public void setIF_enable(boolean iF_enable) {
		IF_enable = iF_enable;
	}
}


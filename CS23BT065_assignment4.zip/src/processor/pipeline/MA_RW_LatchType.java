package processor.pipeline;

public class MA_RW_LatchType {
	
	// Flag to enable or disable the Register Write (RW) stage
	boolean RW_enable;

	// ALU result from the Memory Access (MA) stage
	int aluResult;

	// Load result from memory (if the instruction involves a load operation)
	int ldResult;

	// Destination register where the result will be written
	int rd;

	// Opcode of the instruction being processed
	String opcode;
	
	// Constructor: Initializes the latch with RW disabled by default
	public MA_RW_LatchType() {
		RW_enable = false;
	}

	// Getter for RW enable flag
	public boolean isRW_enable() {
		return RW_enable;
	}

	// Setter for RW enable flag
	public void setRW_enable(boolean rW_enable) {
		RW_enable = rW_enable;
	}

	// Getter for ALU result
	public int getaluResult() {
		return this.aluResult;
	}

	// Setter for ALU result
	public void setaluResult(int aluResult) {
		this.aluResult = aluResult;
	}

	// Getter for load result (used in load instructions)
	public int getldResult() {
		return this.ldResult;
	}

	// Setter for load result
	public void setldResult(int ldResult) {
		this.ldResult = ldResult;
	}

	// Getter for opcode
	public String getopcode() {
		return this.opcode;
	}

	// Setter for opcode
	public void setopcode(String opcode) {
		this.opcode = opcode;
	}

	// Getter for destination register
	public int getDestOperand() {
		return this.rd;
	}

	// Setter for destination register
	public void setDestOperand(int rd) {
		this.rd = rd;
	}
}


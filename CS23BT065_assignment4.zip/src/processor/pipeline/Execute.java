package processor.pipeline;

import java.util.HashMap;

import processor.Processor;
import generic.Instruction;
import generic.Statistics;

public class Execute {
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;

	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch,
			EX_IF_LatchType eX_IF_Latch) {
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}

	public int[] ALU(String opcode, int A, int B, int imm) {
		int aluResult = 0;
		int flagsE = 0, flagsGT = 0, PC = 0;
		switch (opcode) {
			case "00000":
				aluResult = A + B;
				break;
			case "00001":
				aluResult = A + imm;
				break;
			case "00010":
				aluResult = A - B;
				break;
			case "00011":
				aluResult = A - imm;
				break;
			case "00100":
				aluResult = A * B;
				break;
			case "00101":
				aluResult = A * imm;
				break;
			case "00110":
				aluResult = A / B;
				containingProcessor.getRegisterFile().setValue(31, A % B);
				break;
			case "00111":
				aluResult = A / imm;
				
				containingProcessor.getRegisterFile().setValue(31, A % imm);
				break;
			case "01000":
				aluResult = A & B;
				break;
			case "01001":
				aluResult = A & imm;
				break;
			case "01010":
				aluResult = A | B;
				break;
			case "01011":
				aluResult = A | imm;
				break;
			case "01100":
				aluResult = A ^ B;
				break;
			case "01101":
				aluResult = A ^ imm;
				break;
			case "01110":
				aluResult = (A < B) ? 1 : 0;
				break;
			case "01111":
				aluResult = (A < imm) ? 1 : 0;
				break;
			case "10000":
				aluResult = A << B;
				break;
			case "10001":
				aluResult = A << imm;
				break;
			case "10010":
				aluResult = A >>> B;
				break;
			case "10011":
				aluResult = A >>> imm;
				break;
			case "10100":
				aluResult = A >> B;
				break;
			case "10101":
				aluResult = A >> imm;
				break;
			case "10110":
				aluResult = A + imm;
				
				break;
			case "10111":
				aluResult = B + imm;
				
				break;
			case "11000": // jmp
				PC = containingProcessor.getRegisterFile().getProgramCounter()-1;
				PC = PC + A + imm;
				containingProcessor.getRegisterFile().setProgramCounter(PC);
				break;
			case "11001":
				if (A == B) {
					PC = containingProcessor.getRegisterFile().getProgramCounter()-1;
					PC = PC + imm;
					containingProcessor.getRegisterFile().setProgramCounter(PC);
					flagsE = 1;
				}
				break;
			case "11010":
				if (A != B) {
					PC = containingProcessor.getRegisterFile().getProgramCounter()-1;
					PC = PC + imm;
					
					flagsE = 1;
				}
				break;
			case "11011":
				if (A < B) {
					PC = containingProcessor.getRegisterFile().getProgramCounter()-1;
					PC = PC + imm;
		
					flagsGT = 1;
				}
				break;
			case "11100":
				if (A > B) {
					PC = containingProcessor.getRegisterFile().getProgramCounter()-1;
					PC = PC + imm;
					System.out.println("bgt"+" " +imm);
					flagsGT = 1;
				}
				break;

			case "11101":
				// end();
				break;

			default:
		}
		int[] output = { aluResult, flagsE, flagsGT, PC };
		return output;
	}

	public void performEX() {
		// TODO
		
		if (OF_EX_Latch.isEX_enable()) {
			Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions()+1);
			int op1 = OF_EX_Latch.getOperand1();
			int op2 = OF_EX_Latch.getOperand2();
			int imm = OF_EX_Latch.getImm();
			String opcode = OF_EX_Latch.getOpcode();
			int destOperand=OF_EX_Latch.getDestOperand();

			System.out.println("EX:"+opcode);

			if(opcode.equals("11101")){   //end
				EX_MA_Latch.setopcode(opcode);
				OF_EX_Latch.setEX_enable(false);   // if true close EX stage
				EX_MA_Latch.setMA_enable(true);
				return;
			}

			int[] output = ALU(opcode, op1, op2, imm);
			int aluResult = output[0], flagsE = output[1], flagsGT = output[2], PC = output[3];

			if (opcode.equals("11000")) { // jmp
				containingProcessor.getRegisterFile().setProgramCounter(PC);
				OF_EX_Latch.setEX_enable(false);
				EX_IF_Latch.setIF_enable(true);
				return;
			} 
			else if (opcode.equals("11001") || opcode.equals("11010") || 
			opcode.equals("11011") || opcode.equals("11100")) {   //beq bne bgt blt
				if (flagsE == 1 || flagsGT == 1)
					containingProcessor.getRegisterFile().setProgramCounter(PC);
				OF_EX_Latch.setEX_enable(false);
				EX_IF_Latch.setIF_enable(true);
				return;
			} 
			else {
				EX_MA_Latch.setaluResult(aluResult);
				EX_MA_Latch.setOperand1(op1);
				EX_MA_Latch.setOperand2(op2);
				EX_MA_Latch.setopcode(opcode);
				EX_MA_Latch.setDestOperand(destOperand);

				OF_EX_Latch.setEX_enable(false);
				EX_MA_Latch.setMA_enable(true);
			}
		}
	}

}

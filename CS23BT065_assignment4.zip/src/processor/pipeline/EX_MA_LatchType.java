package processor.pipeline;

// This class represents the latch between the Execute (EX) stage and the Memory Access (MA) stage.
public class EX_MA_LatchType {
	
	// Boolean flag to indicate whether the Memory Access stage should be enabled
	boolean MA_enable;

	// Stores operands and results from the ALU operation
	int op1, op2, aluResult, destOperand;

	// Stores the opcode of the instruction being processed
	String opcode;
	
	// Constructor: Initializes the latch with MA stage disabled by default
	public EX_MA_LatchType() {
		MA_enable = false;
	}

	// Getter method to check if MA stage is enabled
	public boolean isMA_enable() {
		return MA_enable;
	}

	// Setter method to enable or disable the MA stage
	public void setMA_enable(boolean mA_enable) {
		MA_enable = mA_enable;
	}

	// Getter and Setter methods for Operand 1
	public int getOperand1() {
		return this.op1;
	}
	public void setOperand1(int op1) {
		this.op1 = op1;
	}

	// Getter and Setter methods for Operand 2
	public int getOperand2() {
		return this.op2;
	}
	public void setOperand2(int op2) {
		this.op2 = op2;
	}

	// Getter and Setter methods for ALU result
	public int getaluResult() {
		return this.aluResult;
	}
	public void setaluResult(int aluResult) {
		this.aluResult = aluResult;
	}

	// Getter and Setter methods for Opcode
	public String getopcode() {
		// System.out.println("fuck you"); // Debugging line (should be removed)
		return this.opcode;
	}
	public void setopcode(String opcode) {
		this.opcode = opcode;
	}

	// Getter and Setter methods for Destination Operand
	public int getDestOperand() {
		return this.destOperand;
	}
	public void setDestOperand(int destOperand) {
		this.destOperand = destOperand;
	}
}


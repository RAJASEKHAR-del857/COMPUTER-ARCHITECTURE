
package processor.pipeline;

import processor.Processor;
import generic.Simulator;

public class InstructionFetch {
	
	// Reference to the processor instance
	Processor containingProcessor;

	// Latches used for inter-stage communication
	IF_EnableLatchType IF_EnableLatch;  // Controls whether instruction fetch (IF) is enabled
	IF_OF_LatchType IF_OF_Latch;        // Latch between IF and Operand Fetch (OF) stage
	EX_IF_LatchType EX_IF_Latch;        // Latch used for branch handling (EX to IF)
	
	// Constructor: Initializes the fetch stage with the necessary references
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, 
	                        IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch) {
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	// Method to perform the instruction fetch stage
	public void performIF() {
		// Check if the IF stage is enabled or if EX stage has issued a jump/branch
		if (IF_EnableLatch.isIF_enable() || EX_IF_Latch.isIF_enable()) {
			
			// Get the current program counter (PC)
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();

			// Fetch the instruction from main memory at address PC
			int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);

			// Store the fetched instruction in the IF_OF latch for the next pipeline stage
			IF_OF_Latch.setInstruction(newInstruction);

			// Increment the program counter to point to the next instruction
			containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);

			// Debugging output for tracking execution
			System.out.println("IF: Instruction Fetch executed");
			System.out.println();

			// Check if the instruction is the "end" instruction (-402653184)
			if (newInstruction == -402653184) {  
				// Disable instruction fetch to halt further execution
				IF_EnableLatch.setIF_enable(false);
			}
			
			// Ensure IF does not continue executing if a branch was taken in EX stage
			EX_IF_Latch.setIF_enable(false);

			// Enable the next stage (Operand Fetch)
			IF_OF_Latch.setOF_enable(true);
		}
	}
}


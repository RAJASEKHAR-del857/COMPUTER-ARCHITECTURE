
package main;

import java.util.ArrayList;
import configuration.Configuration;
import generic.Misc;
import generic.Statistics;
import processor.Processor;
import processor.memorysystem.MainMemory;
import processor.pipeline.RegisterFile;
import generic.Simulator;

public class Main {

	public static void main(String[] args) {
		// Ensure that the program is executed with exactly three arguments.
		if (args.length != 3) {
			Misc.printErrorAndExit("usage: java -jar <path-to-jar-file> <path-to-config-file> <path-to-stat-file> <path-to-object-file>\n");
		}

		// Parse the configuration file provided as the first argument.
		Configuration.parseConfiguratioFile(args[0]);

		// Create a new Processor instance.
		Processor processor = new Processor();

		// Set up the simulation using the object file (third argument) and the processor instance.
		Simulator.setupSimulation(args[2], processor);

		// Run the simulation.
		Simulator.simulate();

		// Print the state of the processor after execution.
		// The range (0, 30) may specify a portion of memory to be displayed (if implemented in printState).
		processor.printState(0, 30);

		// Print the collected statistics to the statistics file (second argument).
		Statistics.printStatistics(args[1]);

		// Print the computed hash of the processor's state (for verification purposes).
		System.out.println("Hash of the Processor State = " + getHashCode(processor.getRegisterFile(), processor.getMainMemory()));
	}

	/**
	 * Computes a hash code for the processor's state using its register file and main memory.
	 * This helps verify correctness by comparing hashes across different runs.
	 *
	 * @param registerState The register file of the processor.
	 * @param memoryState   The main memory of the processor.
	 * @return A computed hash code representing the processor state.
	 */
	static int getHashCode(RegisterFile registerState, MainMemory memoryState) {
		ArrayList<Integer> hash = new ArrayList<>();

		// Add the Program Counter (PC) to the hash.
		hash.add(registerState.getProgramCounter());

		// Add all 32 general-purpose registers to the hash.
		for (int i = 0; i < 32; i++) {
			hash.add(registerState.getValue(i));
		}

		// Add all 65536 words of memory to the hash.
		for (int i = 0; i < 65536; i++) {
			hash.add(memoryState.getWord(i));
		}

		// Compute and return the hash code of the collected data.
		return hash.hashCode();
	}
}


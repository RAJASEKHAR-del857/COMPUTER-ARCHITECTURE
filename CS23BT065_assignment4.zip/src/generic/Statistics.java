
package generic;

import java.io.PrintWriter;

public class Statistics {
	
	// Tracks the total number of executed instructions
	static int numberOfInstructions;

	// Tracks the total number of clock cycles used
	static int numberOfCycles;

	// Tracks the number of stalls due to data hazards in the Operand Fetch (OF) stage
	static int numberOfOFstalls;

	// Tracks the number of control hazards (wrong branch predictions)
	static int numberOfControlHazard;

	/**
	 * Prints the simulation statistics to a specified file.
	 * 
	 * @param statFile The file path where statistics will be written.
	 */
	public static void printStatistics(String statFile) {
		try {
			// Create a writer to output statistics to a file
			PrintWriter writer = new PrintWriter(statFile);

			// Write various statistics to the file
			writer.println("Number of instructions executed = " + numberOfInstructions);
			writer.println("Number of cycles taken = " + numberOfCycles);
			writer.println("Number of times the OF stage needed to stall because of a data hazard = " + numberOfOFstalls);
			writer.println("Number of times an instruction on a wrong branch path entered the pipeline = " + numberOfControlHazard);

			// Close the writer after writing
			writer.close();
		} catch (Exception e) {
			// If an error occurs, print the error message and exit
			Misc.printErrorAndExit(e.getMessage());
		}
	}

	// Getter and Setter for numberOfInstructions
	public static int getNumberOfInstructions() {
		return numberOfInstructions;
	}
	public static void setNumberOfInstructions(int numberOfInstructions) {
		Statistics.numberOfInstructions = numberOfInstructions;
	}

	// Getter and Setter for numberOfCycles
	public static int getNumberOfCycles() {
		return numberOfCycles;
	}
	public static void setNumberOfCycles(int numberOfCycles) {
		Statistics.numberOfCycles = numberOfCycles;
	}

	// Getter and Setter for numberOfOFstalls
	public static int getNumberOfOFstalls() {
		return numberOfOFstalls;
	}
	public static void setNumberOfOFstalls(int numberOfOFstalls) {
		Statistics.numberOfOFstalls = numberOfOFstalls;
	}

	// Getter and Setter for numberOfControlHazard
	public static int getNumberOfControlHazard() {
		return numberOfControlHazard;
	}
	public static void setNumberOfControlHazard(int numberOfControlHazard) {
		Statistics.numberOfControlHazard = numberOfControlHazard;
	}
}


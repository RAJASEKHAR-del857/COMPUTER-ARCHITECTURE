
package generic;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import processor.Clock;
import processor.Processor;

public class Simulator {

    // Processor instance to execute instructions
    static Processor processor;

    // Flag to determine if the simulation is complete
    static boolean simulationComplete;

    // Statistics object to track simulation performance
    static generic.Statistics stats = new Statistics();

    /**
     * Sets up the simulation by loading the program into memory and initializing the processor.
     *
     * @param assemblyProgramFile The binary file containing the assembly program.
     * @param p The processor instance.
     */
    public static void setupSimulation(String assemblyProgramFile, Processor p) {
        Simulator.processor = p;
        loadProgram(assemblyProgramFile); // Load program into memory
        simulationComplete = false; // Reset simulation status
    }

    /**
     * Loads the assembly program into the processor's memory and initializes registers.
     *
     * Responsibilities:
     * 1. Load the program into memory based on the ISA specification.
     * 2. Set the Program Counter (PC) to the first instruction address.
     * 3. Initialize registers:
     *    - x0 = 0
     *    - x1 = 65535
     *    - x2 = 65535
     *
     * @param assemblyProgramFile The binary file containing the program.
     */
    static void loadProgram(String assemblyProgramFile) {
        try (FileInputStream fis = new FileInputStream(assemblyProgramFile)) {
            BufferedInputStream bis = new BufferedInputStream(fis);
            DataInputStream dis = new DataInputStream(bis);

            int PCflag = 0; // Flag to track if the PC has been set
            int PC = 0;      // Program counter address
            int index = 0;   // Memory index

            while (dis.available() >= 4) { // Read file in chunks of 4 bytes
                if (PCflag == 0) {
                    PC = dis.readInt(); // Read first integer as the starting PC
                    processor.getRegisterFile().setProgramCounter(PC);
                    PCflag = 1;
                }
                int val = dis.readInt(); // Read instruction/data word
                processor.getMainMemory().setWord(index, val); // Store in memory
                index++;
            }

            // Initialize registers as per ISA specification
            processor.getRegisterFile().setValue(0, 0);
            processor.getRegisterFile().setValue(1, 65535);
            processor.getRegisterFile().setValue(2, 65535);

            // Close resources
            dis.close();
            bis.close();
            fis.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Runs the simulation by executing the instruction cycle until completion.
     * 
     * Execution order:
     * 1. Perform Read/Write (RW) stage
     * 2. Perform Memory Access (MA) stage
     * 3. Perform Execute (EX) stage
     * 4. Perform Operand Fetch (OF) stage
     * 5. Perform Instruction Fetch (IF) stage
     * 
     * Each stage increments the clock.
     */
    public static void simulate() {
        while (!simulationComplete) {
            processor.getRWUnit().performRW();
            Clock.incrementClock();
            
            processor.getMAUnit().performMA();
            Clock.incrementClock();
            
            processor.getEXUnit().performEX();
            Clock.incrementClock();
            
            processor.getOFUnit().performOF();
            Clock.incrementClock();
            
            processor.getIFUnit().performIF();
            Clock.incrementClock();

            // Increment cycle count
            Statistics.setNumberOfCycles(Statistics.getNumberOfCycles() + 1);
        }

        // TODO: Collect and store final simulation statistics
    }

    /**
     * Marks the simulation as complete.
     * @param value True to stop simulation, false to continue.
     */
    public static void setSimulationComplete(boolean value) {
        simulationComplete = value;
    }
}


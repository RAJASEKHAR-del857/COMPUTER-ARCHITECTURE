package processor.memorysystem;

import java.lang.reflect.Member;

import generic.Element;
import generic.Event;
import generic.MemoryReadEvent;
import generic.MemoryResponseEvent;
import generic.MemoryWriteEvent;
import generic.Simulator;
import generic.Event.EventType;
import processor.Clock;

// MainMemory class representing the main memory component in the processor
public class MainMemory implements Element {
    
    // Memory array to store 65536 words (each word being an int)
    int[] memory;

    // Constructor to initialize the main memory with default size
    public MainMemory() {
        memory = new int[65536];  // Initializing memory array
    }

    // Method to get the word stored at a specific memory address
    public int getWord(int address) {
        return memory[address];
    }

    // Method to set a word at a specific memory address
    public void setWord(int address, int value) {
        memory[address] = value;
    }

    // Method to get memory contents as a string between given addresses
    public String getContentsAsString(int startingAddress, int endingAddress) {
        // Return an empty string if the starting and ending addresses are the same
        if (startingAddress == endingAddress)
            return "";

        StringBuilder sb = new StringBuilder();
        sb.append("\nMain Memory Contents:\n\n");
        
        // Loop through the given range and append memory contents to the string
        for (int i = startingAddress; i <= endingAddress; i++) {
            sb.append(i + "\t\t: " + memory[i] + "\n");
        }
        sb.append("\n");
        return sb.toString();
    }

    // Event handler method to process memory-related events (read/write)
    @Override
    public void handleEvent(Event e) {
        // Check if the event type is a memory read event
        if (e.getEventType() == EventType.MemoryRead) {
            MemoryReadEvent event = (MemoryReadEvent) e;
            
            // Generate a memory response event with the read word
            Simulator.getEventQueue().addEvent(
                new MemoryResponseEvent(
                    Clock.getCurrentTime(),                   // Current time of the clock
                    this,                                     // Source element (MainMemory)
                    event.getRequestingElement(),              // Element that requested the read
                    getWord(event.getAddressToReadFrom())      // Memory content at the specified address
                )
            );
        }

        // Check if the event type is a memory write event
        if (e.getEventType() == EventType.MemoryWrite) {
            MemoryWriteEvent event = (MemoryWriteEvent) e;
            
            // Write the given value to the specified memory address
            setWord(event.getAddressToWriteTo(), event.getValue());
        }
    }
}

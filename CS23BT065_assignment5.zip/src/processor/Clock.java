
package processor;

/**
 * The Clock class is responsible for tracking the number of clock cycles
 * that have elapsed during the execution of the processor simulation.
 */
public class Clock {
	// Static variable to keep track of the current clock cycle
	static long currentTime = 0;

	/**
	 * Increments the clock cycle count by 1.
	 * This method is called after each stage of execution in the simulation.
	 */
	public static void incrementClock() {
		currentTime++;
	}

	/**
	 * Retrieves the current clock cycle count.
	 * 
	 * @return The number of cycles elapsed since the start of the simulation.
	 */
	public static long getCurrentTime() {
		return currentTime;
	}
}


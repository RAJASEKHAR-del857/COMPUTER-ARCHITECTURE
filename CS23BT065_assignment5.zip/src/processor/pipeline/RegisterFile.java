
package processor.pipeline;

public class RegisterFile {
    int[] registerFile; // Array representing 32 registers in the processor
    int programCounter; // Program counter to store the address of the next instruction
    
    // Constructor to initialize the register file
    public RegisterFile() {
        registerFile = new int[32]; // Initializing 32 registers
        registerFile[0] = 0; // Register x0 is always 0 in RISC-V architecture
    }
    
    // Method to get the value stored in a specific register
    public int getValue(int registerNumber) {
        return registerFile[registerNumber];
    }
    
    // Method to set a value to a specific register
    public void setValue(int registerNumber, int value) {
        registerFile[registerNumber] = value;
    }

    // Method to get the current value of the program counter
    public int getProgramCounter() {
        return programCounter;
    }

    // Method to set the program counter to a specific value
    public void setProgramCounter(int programCounter) {
        this.programCounter = programCounter;
    }
    
    // Method to increment the program counter by 1 (for next instruction execution)
    public void incrementProgramCounter() {
        this.programCounter++;
    }
    
    // Method to return the contents of the register file as a formatted string
    public String getContentsAsString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nRegister File Contents:\n\n");
        sb.append("PC" + "\t: " + programCounter + "\n\n");
        
        sb.append("x" + 0 + "\t: " + registerFile[0] + "\n"); // x0 is always 0
        for (int i = 1; i < 32; i++) {
            sb.append("x" + i + "\t: " + registerFile[i] + "\n"); // Printing register values
        }       
        sb.append("\n");
        return sb.toString();
    }
}


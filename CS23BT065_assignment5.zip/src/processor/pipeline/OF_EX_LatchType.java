package processor.pipeline;

// Latch class representing the data and control signals between the OF (Operand Fetch) and EX (Execute) stages
public class OF_EX_LatchType {

    // Control and data signals
    boolean EX_enable;   // Whether the EX stage is enabled
    int BranchTarget;    // Target address for branching
    int op1, op2;        // Operands for the ALU operation
    int imm;             // Immediate value
    int destOperand;     // Destination register operand
    String opcode;       // Opcode of the instruction
    boolean EX_busy;     // Whether the EX stage is busy

    // Constructor to initialize the latch with default values
    public OF_EX_LatchType() {
        EX_enable = false;  // Initially, EX stage is not enabled
        EX_busy = false;    // Initially, EX stage is not busy
    }

    // Getter and setter for EX enable flag
    public boolean isEX_enable() {
        return EX_enable;
    }

    public void setEX_enable(boolean eX_enable) {
        EX_enable = eX_enable;
    }

    // Getter and setter for operand 1
    public int getOperand1() {
        return op1;
    }

    public void setOperand1(int op1) {
        this.op1 = op1;
    }

    // Getter and setter for operand 2
    public int getOperand2() {
        return op2;
    }

    public void setOperand2(int op2) {
        this.op2 = op2;
    }

    // Getter and setter for immediate value
    public int getImm() {
        return imm;
    }

    public void setImm(int imm) {
        this.imm = imm;
    }

    // Getter and setter for opcode
    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }

    // Getter and setter for destination operand
    public int getDestOperand() {
        return this.destOperand;
    }

    public void setDestOperand(int destOperand) {
        this.destOperand = destOperand;
    }

    // Getter and setter for EX busy flag
    public void setEX_busy(boolean eX_busy) {
        this.EX_busy = eX_busy;
    }

    public boolean isEX_busy() {
        return this.EX_busy;
    }
}

package processor.pipeline;

// This class represents the latch that passes data from the Instruction Fetch (IF) stage to the Operand Fetch (OF) stage.
public class IF_OF_LatchType {

    // Flag indicating whether the Operand Fetch (OF) stage is enabled.
    boolean OF_enable;
    // Holds the instruction fetched in the IF stage.
    int instruction;
    // Array representing data interlocks for each of the 32 registers.
    int[] LockArr = new int[32];
    // Variable representing a control interlock.
    int cLock;
    // Flags indicating whether the OF and IF stages are busy.
    boolean OF_busy;
    boolean IF_busy;

    // Constructor to initialize the latch with default values.
    public IF_OF_LatchType() {
        // Initially, OF stage is disabled.
        OF_enable = false;
        // Initialize the data interlock array with 0 (no interlocks).
        LockArr = new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        // Initialize control lock to 0 (no control interlock).
        cLock = 0;
        // Set both OF and IF busy flags to false.
        OF_busy = false;
        IF_busy = false;
    }

    // Getter and setter methods for OF_enable.
    public boolean isOF_enable() {
        return OF_enable;
    }

    public void setOF_enable(boolean oF_enable) {
        OF_enable = oF_enable;
    }

    // Getter and setter methods for the instruction.
    public int getInstruction() {
        return instruction;
    }

    public void setInstruction(int instruction) {
        this.instruction = instruction;
    }

    // Getter and setter methods for data interlocks.
    public int[] getDataInterlocks() {
        return LockArr;
    }

    public void setDataInterlocks(int[] arr) {
        this.LockArr = arr;
    }

    // Getter and setter methods for control interlock.
    public int getControlLock() {
        return cLock;
    }

    public void setControlLock(int cLock) {
        this.cLock = cLock;
    }

    // Getter method for checking if the OF stage is busy.
    public boolean isOF_busy() {
        return OF_enable;
    }

    // Getter and setter methods for IF_busy.
    public boolean isIF_busy() {
        return IF_busy;
    }

    public void setIF_busy(boolean iF_busy) {
        IF_busy = iF_busy;
    }

    // (Commented out) Setter method for OF_busy (not in use).
    // public void setOF_busy(boolean oF_busy){
    //      OF_busy = oF_busy;
    // }

}

package processor.pipeline;

// This class represents the latch between the Execute (EX) and Memory Access (MA) stages of the pipeline.
public class EX_MA_LatchType {

    // Indicates whether the MA stage is enabled.
    boolean MA_enable;
    // Operands used in the ALU operation.
    int op1, op2;
    // Result of the ALU operation.
    int aluResult;
    // Destination operand where the result will be stored.
    int destOperand;
    // Opcode of the instruction being processed.
    String opcode;
    // Indicates whether the MA stage is busy.
    boolean MA_busy;

    // Constructor to initialize the latch with default values.
    public EX_MA_LatchType() {
        MA_enable = false;
        MA_busy = false;
    }

    // Getter and setter methods for MA_enable.
    public boolean isMA_enable() {
        return MA_enable;
    }

    public void setMA_enable(boolean mA_enable) {
        MA_enable = mA_enable;
    }

    // Getter and setter methods for the first operand.
    public int getOperand1() {
        return this.op1;
    }

    public void setOperand1(int op1) {
        this.op1 = op1;
    }

    // Getter and setter methods for the second operand.
    public int getOperand2() {
        return this.op2;
    }

    public void setOperand2(int op2) {
        this.op2 = op2;
    }

    // Getter and setter methods for the ALU result.
    public int getaluResult() {
        return this.aluResult;
    }

    public void setaluResult(int aluResult) {
        this.aluResult = aluResult;
    }

    // Getter and setter methods for the opcode.
    public String getopcode() {
        return this.opcode;
    }

    public void setopcode(String opcode) {
        this.opcode = opcode;
    }

    // Getter and setter methods for the destination operand.
    public int getDestOperand() {
        return this.destOperand;
    }

    public void setDestOperand(int destOperand) {
        this.destOperand = destOperand;
    }

    // Getter and setter methods for MA_busy.
    public boolean isMA_busy() {
        return MA_busy;
    }

    public void setMA_busy(boolean mA_busy) {
        this.MA_busy = mA_busy;
    }
}

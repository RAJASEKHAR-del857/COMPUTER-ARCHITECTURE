package processor.pipeline;

// MA_MM_LatchType class to represent the latch between Memory Access (MA) and Memory Management (MM) stages
public class MA_MM_LatchType {

    // Control signals and data fields for the latch
    boolean MA_enable;     // To indicate whether the MA stage is enabled
    int op1, op2;          // Operands for the operation
    int aluResult;         // Result from the ALU
    int destOperand;       // Destination operand (register)
    String opcode;         // Operation code for the instruction

    // Constructor to initialize the latch
    public MA_MM_LatchType() {
        MA_enable = false;  // By default, the MA stage is not enabled
    }

    // Getter and Setter methods for operand 1
    public int getOperand1() {
        return this.op1;
    }

    public void setOperand1(int op1) {
        this.op1 = op1;
    }

    // Getter and Setter methods for operand 2
    public int getOperand2() {
        return this.op2;
    }

    public void setOperand2(int op2) {
        this.op2 = op2;
    }

    // Getter and Setter methods for the ALU result
    public int getaluResult() {
        return this.aluResult;
    }

    public void setaluResult(int aluResult) {
        this.aluResult = aluResult;
    }

    // Getter and Setter methods for the opcode
    public String getopcode() {
        return this.opcode;
    }

    public void setopcode(String opcode) {
        this.opcode = opcode;
    }

    // Getter and Setter methods for the destination operand
    public int getDestOperand() {
        return this.destOperand;
    }

    public void setDestOperand(int destOperand) {
        this.destOperand = destOperand;
    }
}

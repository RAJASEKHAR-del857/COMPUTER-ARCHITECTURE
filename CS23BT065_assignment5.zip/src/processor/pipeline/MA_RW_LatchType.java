package processor.pipeline;

// MA_RW_LatchType class to represent the latch between Memory Access (MA) and Register Writeback (RW) stages
public class MA_RW_LatchType {

    // Control signals and data fields for the latch
    boolean RW_enable;    // To indicate whether the RW stage is enabled
    int aluResult;        // ALU result from the previous stage
    int ldResult;         // Load result from memory
    int rd;               // Destination register
    String opcode;        // Operation code for the instruction

    // Constructor to initialize the latch
    public MA_RW_LatchType() {
        RW_enable = false;  // By default, the RW stage is not enabled
    }

    // Getter and Setter methods for RW enable signal
    public boolean isRW_enable() {
        return RW_enable;
    }

    public void setRW_enable(boolean rW_enable) {
        RW_enable = rW_enable;
    }

    // Getter and Setter methods for the ALU result
    public int getaluResult() {
        return this.aluResult;
    }

    public void setaluResult(int aluResult) {
        this.aluResult = aluResult;
    }

    // Getter and Setter methods for the load result from memory
    public int getldResult() {
        return this.ldResult;
    }

    public void setldResult(int ldResult) {
        this.ldResult = ldResult;
    }

    // Getter and Setter methods for the opcode
    public String getopcode() {
        return this.opcode;
    }

    public void setopcode(String opcode) {
        this.opcode = opcode;
    }

    // Getter and Setter methods for the destination operand (register)
    public int getDestOperand() {
        return this.rd;
    }

    public void setDestOperand(int rd) {
        this.rd = rd;
    }

    // Check if the RW stage is busy (using the RW enable signal)
    public boolean isRW_busy() {
        return RW_enable;
    }
}

package processor.pipeline;

import configuration.Configuration;
import generic.Element;
import generic.Event;
import generic.MemoryReadEvent;
import generic.MemoryResponseEvent;
import generic.MemoryWriteEvent;
import generic.Simulator;
import processor.Clock;
import processor.Processor;

// MemoryAccess class representing the Memory Access (MA) stage of the pipeline
public class MemoryAccess implements Element {
    Processor containingProcessor;
    EX_MA_LatchType EX_MA_Latch;
    MA_RW_LatchType MA_RW_Latch;

    // Constructor to initialize the memory access stage
    public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch) {
        this.containingProcessor = containingProcessor;
        this.EX_MA_Latch = eX_MA_Latch;
        this.MA_RW_Latch = mA_RW_Latch;
    }

    // Method to perform the memory access operation
    public void performMA() {
        // Check if the MA stage is enabled
        if (EX_MA_Latch.isMA_enable()) {
            int op1 = EX_MA_Latch.getOperand1();
            int op2 = EX_MA_Latch.getOperand2();
            int aluResult = EX_MA_Latch.getaluResult();
            String opcode = EX_MA_Latch.getopcode();
            int destOperand = EX_MA_Latch.getDestOperand();
            int ldResult = 0;

            System.out.println("MA: " + opcode);

            // Check if the MA stage is currently busy
            if (EX_MA_Latch.isMA_busy()) {
                System.out.println("MA stage is busy");
                return;
            }

            // Handle the "end" instruction (opcode "11101")
            if (opcode.equals("11101")) {
                MA_RW_Latch.setopcode(opcode);
                EX_MA_Latch.setMA_enable(false); // Disable MA stage
                MA_RW_Latch.setRW_enable(true);  // Enable RW stage
            }

            // Handle the "store" instruction (opcode "10111")
            else if (opcode.equals("10111")) {
                int mar = aluResult;  // Memory Address Register
                int mdr = op1;        // Memory Data Register

                // Generate a memory write event and add it to the event queue
                Simulator.getEventQueue().addEvent(
                    new MemoryWriteEvent(
                        Clock.getCurrentTime() + Configuration.mainMemoryLatency,
                        this,
                        containingProcessor.getMainMemory(),
                        mar,
                        mdr
                    )
                );
            }

            // Handle the "load" instruction (opcode "10110")
            else if (opcode.equals("10110")) {
                int mar = aluResult;

                // Generate a memory read event and add it to the event queue
                Simulator.getEventQueue().addEvent(
                    new MemoryReadEvent(
                        Clock.getCurrentTime() + Configuration.mainMemoryLatency,
                        this,
                        containingProcessor.getMainMemory(),
                        mar
                    )
                );
                EX_MA_Latch.setMA_busy(true);  // Set MA stage as busy
            }

            // Handle ALU and other operations
            else {
                MA_RW_Latch.setDestOperand(destOperand);
                MA_RW_Latch.setaluResult(aluResult);
                MA_RW_Latch.setldResult(ldResult);
                MA_RW_Latch.setopcode(opcode);

                // Disable MA stage and enable RW stage
                EX_MA_Latch.setMA_enable(false);
                MA_RW_Latch.setRW_enable(true);
            }
        }
    }

    // Event handler method for memory access responses
    @Override
    public void handleEvent(Event e) {
        int op1 = EX_MA_Latch.getOperand1();
        int op2 = EX_MA_Latch.getOperand2();
        int aluResult = EX_MA_Latch.getaluResult();
        String opcode = EX_MA_Latch.getopcode();
        int destOperand = EX_MA_Latch.getDestOperand();

        // Check if RW stage is busy and reschedule the event if needed
        if (MA_RW_Latch.isRW_busy()) {
            e.setEventTime(Clock.getCurrentTime() + 1);
            Simulator.getEventQueue().addEvent(e);
        } else {
            // Handle the memory response event
            MemoryResponseEvent event = (MemoryResponseEvent) e;
            MA_RW_Latch.setDestOperand(destOperand);
            MA_RW_Latch.setaluResult(aluResult);
            MA_RW_Latch.setldResult(event.getValue());
            MA_RW_Latch.setopcode(opcode);

            // Mark MA stage as not busy and disable it
            EX_MA_Latch.setMA_busy(false);
            EX_MA_Latch.setMA_enable(false);
            MA_RW_Latch.setRW_enable(true);
        }
    }
}

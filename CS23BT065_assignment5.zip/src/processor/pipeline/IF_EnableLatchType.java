package processor.pipeline;

// This class represents the latch that controls the enable signal for the Instruction Fetch (IF) stage.
public class IF_EnableLatchType {

    // Indicates whether the IF stage is enabled.
    boolean IF_enable;
    // Indicates whether the IF stage is busy.
    boolean IF_busy;

    // Constructor to initialize the latch with default values.
    public IF_EnableLatchType() {
        // Initially, the IF stage is enabled and not busy.
        IF_enable = true;
        IF_busy = false;
    }

    // Getter and setter methods for IF_enable.
    public boolean isIF_enable() {
        return IF_enable;
    }

    public void setIF_enable(boolean iF_enable) {
        IF_enable = iF_enable;
    }

    // Getter and setter methods for IF_busy.
    public boolean isIF_busy() {
        return IF_busy;
    }

    public void setIF_busy(boolean iF_busy) {
        IF_busy = iF_busy;
    }

}

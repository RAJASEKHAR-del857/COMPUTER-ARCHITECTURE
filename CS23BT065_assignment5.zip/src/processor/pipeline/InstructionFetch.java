package processor.pipeline;

import processor.Clock;
import processor.Processor;
import configuration.Configuration;
import generic.MemoryReadEvent;
import generic.MemoryResponseEvent;
import generic.Simulator;
import generic.Statistics;
import generic.Element;
import generic.Event;

// This class handles the Instruction Fetch (IF) stage of the pipeline.
public class InstructionFetch implements Element {

    // Processor instance to access core components.
    Processor containingProcessor;
    // Latch types to manage communication between pipeline stages.
    IF_EnableLatchType IF_EnableLatch;
    IF_OF_LatchType IF_OF_Latch;
    EX_IF_LatchType EX_IF_Latch;

    // Constructor to initialize the Instruction Fetch stage with the necessary components.
    public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch) {
        this.containingProcessor = containingProcessor;
        this.IF_EnableLatch = iF_EnableLatch;
        this.IF_OF_Latch = iF_OF_Latch;
        this.EX_IF_Latch = eX_IF_Latch;
    }

    // Method to perform the Instruction Fetch operation.
    public void performIF() {
        // Check if the IF stage is enabled.
        if (IF_EnableLatch.isIF_enable()) {
            // If the IF stage or OF stage is busy, return without performing any operation.
            if (IF_EnableLatch.isIF_busy()) {
                System.out.println(IF_EnableLatch.isIF_busy());
                return;
            }
            if (IF_OF_Latch.isIF_busy()) {
                System.out.println("IF_busy :hello");
                return;
            }

            // Add a memory read event to the event queue.
            Simulator.getEventQueue().addEvent(
                new MemoryReadEvent(
                    Clock.getCurrentTime() + Configuration.mainMemoryLatency,  // Event time considering memory latency.
                    this,                                                      // Source element (InstructionFetch).
                    containingProcessor.getMainMemory(),                       // Target memory.
                    containingProcessor.getRegisterFile().getProgramCounter()  // Address to fetch the instruction from.
                )
            );

            // Mark the IF stage as busy after scheduling the memory read.
            IF_EnableLatch.setIF_busy(true);
        }
    }

    // Handle events related to instruction fetch (such as memory response).
    @Override
    public void handleEvent(Event e) {
        // Check if the Operand Fetch (OF) stage is busy. If yes, delay the event.
        if (IF_OF_Latch.isOF_busy()) {
            e.setEventTime(Clock.getCurrentTime() + 1);  // Delay the event by one cycle.
            Simulator.getEventQueue().addEvent(e);       // Re-add the event to the queue.
        } else {
            System.out.println(Clock.getCurrentTime());
            // Handle the memory response event and fetch the instruction.
            MemoryResponseEvent event = (MemoryResponseEvent) e;
            IF_OF_Latch.setInstruction(event.getValue());

            // Update the program counter to the next instruction.
            int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
            int newInstruction = event.getValue();
            Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions() + 1);
            containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);

            // Check if the fetched instruction is an "end" instruction (indicated by -402653184).
            if (newInstruction == -402653184) {
                // Disable the IF stage as the program has reached the end.
                IF_EnableLatch.setIF_enable(false);
            }

            // Enable the Operand Fetch (OF) stage and mark IF as not busy.
            IF_OF_Latch.setOF_enable(true);
            IF_EnableLatch.setIF_busy(false);
        }
    }

}

package processor.pipeline;

import java.util.HashMap;
import processor.Processor;
import generic.Instruction;
import generic.Statistics;

/**
 * The Execute class handles the execution stage of the pipeline in a processor.
 * It performs arithmetic and logical operations, as well as control flow operations.
 */
public class Execute {
    Processor containingProcessor;
    OF_EX_LatchType OF_EX_Latch;
    EX_MA_LatchType EX_MA_Latch;
    EX_IF_LatchType EX_IF_Latch;

    /**
     * Constructor to initialize the Execute stage.
     * 
     * @param containingProcessor The processor containing this stage.
     * @param oF_EX_Latch         Latch between OF and EX stages.
     * @param eX_MA_Latch         Latch between EX and MA stages.
     * @param eX_IF_Latch         Latch between EX and IF stages.
     */
    public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch,
                   EX_IF_LatchType eX_IF_Latch) {
        this.containingProcessor = containingProcessor;
        this.OF_EX_Latch = oF_EX_Latch;
        this.EX_MA_Latch = eX_MA_Latch;
        this.EX_IF_Latch = eX_IF_Latch;
    }

    /**
     * Arithmetic Logic Unit (ALU) to perform operations based on opcode.
     * 
     * @param opcode The operation code.
     * @param A      The first operand.
     * @param B      The second operand.
     * @param imm    Immediate value (if applicable).
     * @return An integer array containing ALU result, flags (E, GT), and updated PC.
     */
    public int[] ALU(String opcode, int A, int B, int imm) {
        int aluResult = 0;
        int flagsE = 0, flagsGT = 0, PC = 0;

        // Switch case to handle various opcodes
        switch (opcode) {
            case "00000": // ADD
                aluResult = A + B;
                break;
            case "00001": // ADD with immediate
                aluResult = A + imm;
                break;
            case "00010": // SUBTRACT
                aluResult = A - B;
                break;
            case "00011": // SUBTRACT with immediate
                aluResult = A - imm;
                break;
            case "00100": // MULTIPLY
                aluResult = A * B;
                break;
            case "00101": // MULTIPLY with immediate
                aluResult = A * imm;
                break;
            case "00110": // DIVIDE
                aluResult = A / B;
                containingProcessor.getRegisterFile().setValue(31, A % B); // R31 stores the remainder
                break;
            case "00111": // DIVIDE with immediate
                aluResult = A / imm;
                containingProcessor.getRegisterFile().setValue(31, A % imm); // R31 stores the remainder
                break;
            case "01000": // AND
                aluResult = A & B;
                break;
            case "01001": // AND with immediate
                aluResult = A & imm;
                break;
            case "01010": // OR
                aluResult = A | B;
                break;
            case "01011": // OR with immediate
                aluResult = A | imm;
                break;
            case "01100": // XOR
                aluResult = A ^ B;
                break;
            case "01101": // XOR with immediate
                aluResult = A ^ imm;
                break;
            case "01110": // Set if less than
                aluResult = (A < B) ? 1 : 0;
                break;
            case "01111": // Set if less than (immediate)
                aluResult = (A < imm) ? 1 : 0;
                break;
            case "10000": // Shift left
                aluResult = A << B;
                break;
            case "10001": // Shift left with immediate
                aluResult = A << imm;
                break;
            case "10010": // Logical right shift
                aluResult = A >>> B;
                break;
            case "10011": // Logical right shift with immediate
                aluResult = A >>> imm;
                break;
            case "10100": // Arithmetic right shift
                aluResult = A >> B;
                break;
            case "10101": // Arithmetic right shift with immediate
                aluResult = A >> imm;
                break;
            case "10110": // Addition with immediate
                aluResult = A + imm;
                break;
            case "10111": // Addition of B and immediate
                aluResult = B + imm;
                break;
            case "11000": // Jump
                PC = containingProcessor.getRegisterFile().getProgramCounter() - 1 + A + imm;
                containingProcessor.getRegisterFile().setProgramCounter(PC);
                break;
            case "11001": // BEQ (Branch if equal)
                if (A == B) {
                    PC = containingProcessor.getRegisterFile().getProgramCounter() - 1 + imm;
                    flagsE = 1;
                }
                break;
            case "11010": // BNE (Branch if not equal)
                if (A != B) {
                    PC = containingProcessor.getRegisterFile().getProgramCounter() - 1 + imm;
                    flagsE = 1;
                }
                break;
            case "11011": // BLT (Branch if less than)
                if (A < B) {
                    PC = containingProcessor.getRegisterFile().getProgramCounter() - 1 + imm;
                    flagsGT = 1;
                }
                break;
            case "11100": // BGT (Branch if greater than)
                if (A > B) {
                    PC = containingProcessor.getRegisterFile().getProgramCounter() - 1 + imm;
                    flagsGT = 1;
                    System.out.println("bgt " + imm);
                }
                break;
            case "11101": // End of program
                break;
            default:
                break;
        }

        int[] output = { aluResult, flagsE, flagsGT, PC };
        return output;
    }

    /**
     * Execute the instruction in the pipeline.
     */
    public void performEX() {
        if (OF_EX_Latch.isEX_enable()) {
            int op1 = OF_EX_Latch.getOperand1();
            int op2 = OF_EX_Latch.getOperand2();
            int imm = OF_EX_Latch.getImm();
            String opcode = OF_EX_Latch.getOpcode();
            int destOperand = OF_EX_Latch.getDestOperand();

            System.out.println("EX:" + opcode);

            if (opcode.equals("11101")) { // End instruction
                EX_MA_Latch.setopcode(opcode);
                OF_EX_Latch.setEX_enable(false);
                EX_MA_Latch.setMA_enable(true);
                return;
            }

            int[] output = ALU(opcode, op1, op2, imm);
            int aluResult = output[0], flagsE = output[1], flagsGT = output[2], PC = output[3];

            if (opcode.equals("11000")) { // Jump
                containingProcessor.getRegisterFile().setProgramCounter(PC);
                OF_EX_Latch.setEX_enable(false);
                EX_IF_Latch.setIF_enable(true);
                return;
            } else if (opcode.startsWith("110") && !opcode.equals("11000")) { // Branch operations
                if (flagsE == 1 || flagsGT == 1)
                    containingProcessor.getRegisterFile().setProgramCounter(PC);
                OF_EX_Latch.setEX_enable(false);
                EX_IF_Latch.setIF_enable(true);
                return;
            } else {
                if (EX_MA_Latch.isMA_busy()) {
                    OF_EX_Latch.setEX_busy(true);
                    return;
                }

                EX_MA_Latch.setaluResult(aluResult);
                EX_MA_Latch.setOperand1(op1);
                EX_MA_Latch.setOperand2(op2);
                EX_MA_Latch.setopcode(opcode);
                EX_MA_Latch.setDestOperand(destOperand);

                OF_EX_Latch.setEX_enable(false);
                EX_MA_Latch.setMA_enable(true);
                OF_EX_Latch.setEX_busy(false);
            }
        }
    }
}

package processor.pipeline;

import generic.Simulator;
import processor.Processor;

public class RegisterWrite {
    // Reference to the processor containing this stage
    Processor containingProcessor;

    // Latch for data transfer from Memory Access (MA) to Register Write (RW)
    MA_RW_LatchType MA_RW_Latch;

    // Latch to enable the Instruction Fetch (IF) stage
    IF_EnableLatchType IF_EnableLatch;

    // Latch for data interlocking (to handle data hazards)
    IF_OF_LatchType IF_OF_Latch;

    // Constructor to initialize the class with necessary references
    public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch,
                         IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch) {
        this.containingProcessor = containingProcessor;
        this.MA_RW_Latch = mA_RW_Latch;
        this.IF_EnableLatch = iF_EnableLatch;
        this.IF_OF_Latch = iF_OF_Latch;
    }

    // Method to perform the Register Write (RW) stage of the pipeline
    public void performRW() {
        // Get the opcode of the instruction currently being processed
        String opcode = MA_RW_Latch.getopcode();

        // Check if RW stage is enabled and the instruction is not a store (opcode "10111")
        if (MA_RW_Latch.isRW_enable() && !opcode.equals("10111")) {
            // Retrieve results from the Memory Access (MA) stage
            int aluResult = MA_RW_Latch.getaluResult();  // Result from ALU computation
            int ldResult = MA_RW_Latch.getldResult();    // Result from load instruction
            int rd = MA_RW_Latch.getDestOperand();       // Destination register
            int result = 0;  // Variable to store the final value to be written

            // Print the opcode for debugging purposes
            System.out.println("RW: " + opcode);

            // If the instruction is an "end" instruction (opcode "11101"), stop the simulation
            if (opcode.equals("11101")) { 
                Simulator.setSimulationComplete(true);
                MA_RW_Latch.setRW_enable(false);  // Disable RW stage as execution is complete
                return;
            }

            // If the instruction is a load (opcode "10110"), use the loaded value
            if (opcode.equals("10110")) {
                result = ldResult;
            } else {
                // Otherwise, use the ALU result
                result = aluResult;
            }

            // Write the computed value to the destination register
            containingProcessor.getRegisterFile().setValue(rd, result);

            // Data interlocking handling: decrease the lock count on the register
            int[] LockArr = IF_OF_Latch.getDataInterlocks();
            if (rd >= 0 && rd < LockArr.length && LockArr[rd] > 0) {
                LockArr[rd]--;
            }

            System.out.println(rd + " " + LockArr[rd]); // Debugging output
        }

        // Disable RW stage for the next cycle
        MA_RW_Latch.setRW_enable(false);
    }
}

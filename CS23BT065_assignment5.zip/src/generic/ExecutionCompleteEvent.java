package generic;

// This class represents an event that signifies the completion of an execution.
public class ExecutionCompleteEvent extends Event {

    // Constructor to initialize the execution complete event with event time, requesting element, and processing element.
    public ExecutionCompleteEvent(long eventTime, Element requestingElement, Element processingElement) {
        // Call the superclass constructor to initialize the event with the specified parameters.
        super(eventTime, EventType.ExecutionComplete, requestingElement, processingElement);
    }

}

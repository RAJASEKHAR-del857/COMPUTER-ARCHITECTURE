package generic;

/**
 * An interface representing an element that can handle events.
 * Any class implementing this interface must define the handleEvent() method.
 */
public interface Element {

    /**
     * Handles an incoming event.
     * 
     * @param event The event to be handled.
     */
    void handleEvent(Event event);

}

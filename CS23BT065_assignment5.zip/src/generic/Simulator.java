package generic;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import processor.Clock;
import processor.Processor;

public class Simulator {
    
    // Declaring static variables
    static Processor processor;
    static boolean simulationComplete;
    static generic.Statistics stats = new Statistics();
    static generic.EventQueue eventQueue;
    
    // Set up the simulation environment
    public static void setupSimulation(String assemblyProgramFile, Processor p) {
        Simulator.processor = p;
        eventQueue = new EventQueue();
        loadProgram(assemblyProgramFile);  // Load the assembly program into memory
        
        simulationComplete = false;  // Mark the simulation as not complete
    }

    // Load the program from a binary file and initialize registers and memory
    static void loadProgram(String assemblyProgramFile) {
        /*
         * Load the program into memory according to the layout specified in the ISA.
         * Set the Program Counter (PC) to the first instruction address.
         * Initialize registers:
         *   x0 = 0
         *   x1 = 65535
         *   x2 = 65535
         */
        try (FileInputStream fis = new FileInputStream(assemblyProgramFile)) {
            BufferedInputStream bis = new BufferedInputStream(fis);
            DataInputStream dis = new DataInputStream(bis);
            
            int PCflag = 0, PC = 0, index = 0;
            
            // Read the program from the binary file in 4-byte (32-bit) chunks
            while (dis.available() >= 4) {
                if (PCflag == 0) {
                    // Read the initial Program Counter value from the file
                    PC = dis.readInt();
                    processor.getRegisterFile().setProgramCounter(PC);
                    PCflag = 1;
                }
                int val = dis.readInt();
                // Load each word into the memory
                processor.getMainMemory().setWord(index, val);
                index++;
            }

            // Initialize the special registers as specified
            processor.getRegisterFile().setValue(0, 0);       // x0 = 0
            processor.getRegisterFile().setValue(1, 65535);    // x1 = 65535
            processor.getRegisterFile().setValue(2, 65535);    // x2 = 65535
            
            // Close streams
            dis.close();
            bis.close();
            fis.close();

            // Debugging: Print memory and register contents (if needed)
            // System.out.println(processor.getMainMemory().getContentsAsString(0, index));
            // System.out.println(processor.getRegisterFile().getContentsAsString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Run the simulation by executing pipeline stages
    public static void simulate() {
        while (simulationComplete == false) {
            // Execute the pipeline stages in reverse order to avoid hazards

            // Perform the Read/Write (RW) stage
            processor.getRWUnit().performRW();
            
            // Perform the Memory Access (MA) stage
            processor.getMAUnit().performMA();
            
            // Perform the Execute (EX) stage
            processor.getEXUnit().performEX();

            // Process any pending events (e.g., from interrupts or stalls)
            eventQueue.processEvents();

            // Perform the Operand Fetch (OF) stage
            processor.getOFUnit().performOF();

            // Perform the Instruction Fetch (IF) stage
            processor.getIFUnit().performIF();
            
            // Increment the global clock after all stages have executed
            Clock.incrementClock();
            
            // Increment the cycle count in the statistics
            Statistics.setNumberOfCycles(Statistics.getNumberOfCycles() + 1);
        }
        
        // Set final statistics when the simulation completes
        // long theLong = Clock.getCurrentTime();
        // int i = (int) (long) theLong;
        // stats.setNumberOfCycles(i);
        // stats.setNumberOfInstructions(instruction);
    }

    // Mark the simulation as complete
    public static void setSimulationComplete(boolean value) {
        simulationComplete = value;
    }

    // Get the global event queue
    public static EventQueue getEventQueue() {
        return eventQueue;
    }
}

package generic;

import java.io.PrintWriter;

public class Statistics {
	
	// Static variables to store various statistics
	static int numberOfInstructions;      // Total number of instructions executed
	static int numberOfCycles;            // Total number of clock cycles taken
	static int numberOfOFstalls;          // Number of stalls due to data hazards in the Operand Fetch (OF) stage
	static int NumberOfControlHazard;     // Number of control hazards encountered (branch mispredictions)
	
	// Print the collected statistics to a file
	public static void printStatistics(String statFile) {
		try {
			// Create a PrintWriter to write statistics to the specified file
			PrintWriter writer = new PrintWriter(statFile);
			
			// Calculate throughput as the ratio of instructions executed to the number of cycles
			double Throughput = (double) numberOfInstructions / numberOfCycles;
			
			// Print the collected statistics
			writer.println("Number of instructions executed = " + numberOfInstructions);
			writer.println("Number of cycles taken = " + numberOfCycles);
			writer.println("Number of times the OF stage needed to stall because of a data hazard = " + numberOfOFstalls);
			writer.println("Number of times an instruction on a wrong branch path entered the pipeline = " + NumberOfControlHazard);
			writer.println("Throughput in terms of instructions per cycle = " + Throughput);
			
			// Close the writer after printing the statistics
			writer.close();
		} catch (Exception e) {
			// Print the error message and exit if an exception occurs
			Misc.printErrorAndExit(e.getMessage());
		}
	}
	
	// Getter and Setter for number of instructions
	public static int getNumberOfInstructions() {
		return numberOfInstructions;
	}
	public static void setNumberOfInstructions(int numberOfInstructions) {
		Statistics.numberOfInstructions = numberOfInstructions;
	}

	// Getter and Setter for number of cycles
	public static int getNumberOfCycles() {
		return numberOfCycles;
	}
	public static void setNumberOfCycles(int numberOfCycles) {
		Statistics.numberOfCycles = numberOfCycles;
	}

	// Getter and Setter for number of Operand Fetch (OF) stage stalls
	public static int getNumberOfOFstalls() {
		return numberOfOFstalls;
	}
	public static void setNumberOfOFstalls(int numberOfOFstalls) {
		Statistics.numberOfOFstalls = numberOfOFstalls;
	}

	// Getter and Setter for number of control hazards (branch mispredictions)
	public static int getNumberOfControlHazard() {
		return NumberOfControlHazard;
	}
	public static void setNumberOfControlHazard(int NumberOfControlHazard) {
		Statistics.NumberOfControlHazard = NumberOfControlHazard;
	}
}

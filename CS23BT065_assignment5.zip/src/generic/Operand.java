
package generic;

public class Operand {

    // Enum defining the type of operand: Register, Immediate, or Label
    public enum OperandType {Register, Immediate, Label};

    // The type of this operand (Register, Immediate, or Label)
    private OperandType operandType;

    // Stores the integer value for Register or Immediate types
    private int value;

    // Stores the string label for Label type (used in functional emulation)
    private String labelValue;

    // Getter for operand type
    public OperandType getOperandType() {
        return operandType;
    }

    // Setter for operand type
    public void setOperandType(OperandType operandType) {
        this.operandType = operandType;
    }

    // Getter for value (used when operand is Register or Immediate)
    public int getValue() {
        return value;
    }

    // Setter for value
    public void setValue(int value) {
        this.value = value;
    }

    // Getter for labelValue (used when operand is a Label)
    public String getLabelValue() {
        return labelValue;
    }

    // Setter for labelValue
    public void setLabelValue(String labelValue) {
        this.labelValue = labelValue;
    }

    // Converts the operand to a string representation for debugging and logging
    @Override
    public String toString() {
        // If the operand is a Register or an Immediate value, return the integer value
        if (operandType == OperandType.Register || operandType == OperandType.Immediate) {
            return "[" + operandType.toString() + ":" + value + "]";
        } 
        // If the operand is a Label, return the label string
        else {
            return "[" + operandType.toString() + ":" + labelValue + "]";
        }
    }
}


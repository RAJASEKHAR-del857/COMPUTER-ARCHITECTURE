package generic;

/**
 * The Event class represents an event that occurs during simulation.
 * It contains information about the event type, the time it occurs,
 * the element that requested it, and the element that will process it.
 */
public class Event {

    // Enumeration to define different types of events.
    public enum EventType {
        ExecutionComplete,  // Indicates that execution has completed.
        MemoryRead,         // Represents a memory read event.
        MemoryResponse,     // Represents a response to a memory read.
        MemoryWrite         // Represents a memory write event.
    };

    // The time at which the event is scheduled to occur.
    long eventTime;
    // The element that requested the event.
    Element requestingElement;
    // The element that will process the event.
    Element processingElement;
    // The type of event being represented.
    EventType eventType;

    /**
     * Constructor to initialize an event with the given parameters.
     * 
     * @param eventTime The time at which the event is scheduled to occur.
     * @param eventType The type of the event.
     * @param requestingElement The element that requested the event.
     * @param processingElement The element that will process the event.
     */
    public Event(long eventTime, EventType eventType, Element requestingElement, Element processingElement) {
        this.eventTime = eventTime;
        this.eventType = eventType;
        this.requestingElement = requestingElement;
        this.processingElement = processingElement;
    }

    /**
     * Gets the time at which the event is scheduled to occur.
     * 
     * @return The event time.
     */
    public long getEventTime() {
        return eventTime;
    }

    /**
     * Sets the time at which the event will occur.
     * 
     * @param eventTime The event time to set.
     */
    public void setEventTime(long eventTime) {
        this.eventTime = eventTime;
    }

    /**
     * Gets the element that requested the event.
     * 
     * @return The requesting element.
     */
    public Element getRequestingElement() {
        return requestingElement;
    }

    /**
     * Sets the element that requested the event.
     * 
     * @param requestingElement The requesting element to set.
     */
    public void setRequestingElement(Element requestingElement) {
        this.requestingElement = requestingElement;
    }

    /**
     * Gets the element that will process the event.
     * 
     * @return The processing element.
     */
    public Element getProcessingElement() {
        return processingElement;
    }

    /**
     * Sets the element that will process the event.
     * 
     * @param processingElement The processing element to set.
     */
    public void setProcessingElement(Element processingElement) {
        this.processingElement = processingElement;
    }

    /**
     * Gets the type of the event.
     * 
     * @return The event type.
     */
    public EventType getEventType() {
        return eventType;
    }

    /**
     * Sets the type of the event.
     * 
     * @param eventType The event type to set.
     */
    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }
}

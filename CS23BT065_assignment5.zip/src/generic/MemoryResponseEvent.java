package generic;

// MemoryResponseEvent class representing a memory read response event
public class MemoryResponseEvent extends Event {

    // Value that was read from memory
    int value;

    // Constructor to initialize the memory response event
    public MemoryResponseEvent(long eventTime, Element requestingElement, Element processingElement, int value) {
        // Call the parent constructor with event time, event type, requesting element, and processing element
        super(eventTime, EventType.MemoryResponse, requestingElement, processingElement);
        this.value = value;  // Set the value that was read from memory
    }

    // Getter method for the value read from memory
    public int getValue() {
        return value;
    }

    // Setter method for the value read from memory
    public void setValue(int value) {
        this.value = value;
    }
}

package generic;

// MemoryWriteEvent class representing a memory write request event
public class MemoryWriteEvent extends Event {

    // Address to write to and the value to be written
    int addressToWriteTo;
    int value;

    // Constructor to initialize the memory write event
    public MemoryWriteEvent(long eventTime, Element requestingElement, Element processingElement, int address, int value) {
        // Call the parent constructor with event time, event type, requesting element, and processing element
        super(eventTime, EventType.MemoryWrite, requestingElement, processingElement);
        this.addressToWriteTo = address;  // Set the address to write to
        this.value = value;               // Set the value to be written
    }

    // Getter method for the address to write to
    public int getAddressToWriteTo() {
        return addressToWriteTo;
    }

    // Setter method for the address to write to
    public void setAddressToWriteTo(int addressToWriteTo) {
        this.addressToWriteTo = addressToWriteTo;
    }

    // Getter method for the value to be written
    public int getValue() {
        return value;
    }

    // Setter method for the value to be written
    public void setValue(int value) {
        this.value = value;
    }
}

package generic;

// MemoryReadEvent class representing a memory read operation event
public class MemoryReadEvent extends Event {

    // Address from which data is to be read
    int addressToReadFrom;

    // Constructor to initialize the memory read event
    public MemoryReadEvent(long eventTime, Element requestingElement, Element processingElement, int address) {
        // Call the parent constructor with event time, event type, requesting element, and processing element
        super(eventTime, EventType.MemoryRead, requestingElement, processingElement);
        this.addressToReadFrom = address;  // Set the address to read from
    }

    // Getter method for the address to read from
    public int getAddressToReadFrom() {
        return addressToReadFrom;
    }

    // Setter method for the address to read from
    public void setAddressToReadFrom(int addressToReadFrom) {
        this.addressToReadFrom = addressToReadFrom;
    }
}

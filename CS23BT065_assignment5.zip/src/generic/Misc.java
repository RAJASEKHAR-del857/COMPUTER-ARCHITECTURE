package generic;

/**
 * Utility class for handling miscellaneous operations.
 * Currently, it provides a method to print an error message and exit the program.
 */
public class Misc {
    
    /**
     * Prints an error message to standard error and exits the program.
     * 
     * @param message The error message to be displayed.
     */
    public static void printErrorAndExit(String message)
    {
        System.err.println(message); // Print the error message to the error stream
        System.exit(1); // Terminate the program with exit code 1 (indicating an error)
    }
}


package generic;

import java.util.Comparator;
import java.util.PriorityQueue;

import processor.Clock;

/**
 * The EventQueue class manages events that occur during simulation.
 * It uses a priority queue to store events in order of their scheduled time.
 */
public class EventQueue {

    // Priority queue to hold events, ordered by event time.
    PriorityQueue<Event> queue;

    /**
     * Constructor to initialize the event queue with a custom comparator.
     */
    public EventQueue() {
        // Create a priority queue using EventComparator to order events by time.
        queue = new PriorityQueue<Event>(new EventComparator());
    }

    /**
     * Adds an event to the event queue.
     * 
     * @param event The event to be added to the queue.
     */
    public void addEvent(Event event) {
        queue.add(event);
    }

    /**
     * Processes events whose scheduled time has arrived.
     * It checks the event at the top of the queue and processes it if the current clock time has reached or passed the event time.
     */
    public void processEvents() {
        // Loop while the queue is not empty and the event time is less than or equal to the current clock time.
        while (!queue.isEmpty() && queue.peek().getEventTime() <= Clock.getCurrentTime()) {
            // Remove the event from the queue and process it.
            Event event = queue.poll();
            event.getProcessingElement().handleEvent(event);
        }
    }
}

/**
 * Comparator class to compare two events based on their scheduled event time.
 */
class EventComparator implements Comparator<Event> {
    
    /**
     * Compares two events to determine their order in the priority queue.
     * 
     * @param x The first event.
     * @param y The second event.
     * @return -1 if x occurs before y, 1 if x occurs after y, 0 if they are equal.
     */
    @Override
    public int compare(Event x, Event y) {
        if (x.getEventTime() < y.getEventTime()) {
            return -1; // x should be before y
        } else if (x.getEventTime() > y.getEventTime()) {
            return 1;  // x should be after y
        } else {
            return 0;  // x and y are equal in time
        }
    }
}

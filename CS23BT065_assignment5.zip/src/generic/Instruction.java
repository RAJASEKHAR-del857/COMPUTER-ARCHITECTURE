package generic;

// Class representing an instruction in the processor
public class Instruction {
	
	// Enum defining various operation types an instruction can perform
	public enum OperationType {
		add, addi, sub, subi, mul, muli, div, divi, and, andi, or, ori, xor, xori, 
		slt, slti, sll, slli, srl, srli, sra, srai, load, store, jmp, beq, bne, blt, bgt, end
	};
	
	// Fields representing instruction properties
	int programCounter; // Stores the instruction's address in memory
	OperationType operationType; // The type of operation the instruction performs
	Operand sourceOperand1; // First source operand
	Operand sourceOperand2; // Second source operand (if applicable)
	Operand destinationOperand; // Destination operand (if applicable)
	
	// Getter and Setter for program counter
	public int getProgramCounter() {
		return programCounter;
	}
	public void setProgramCounter(int programCounter) {
		this.programCounter = programCounter;
	}
	
	// Getter and Setter for operation type
	public OperationType getOperationType() {
		return operationType;
	}
	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}
	
	// Getter and Setter for source operand 1
	public Operand getSourceOperand1() {
		return sourceOperand1;
	}
	public void setSourceOperand1(Operand sourceOperand1) {
		this.sourceOperand1 = sourceOperand1;
	}
	
	// Getter and Setter for source operand 2
	public Operand getSourceOperand2() {
		return sourceOperand2;
	}
	public void setSourceOperand2(Operand sourceOperand2) {
		this.sourceOperand2 = sourceOperand2;
	}
	
	// Getter and Setter for destination operand
	public Operand getDestinationOperand() {
		return destinationOperand;
	}
	public void setDestinationOperand(Operand destinationOperand) {
		this.destinationOperand = destinationOperand;
	}
	
	// Converts instruction details into a string representation for debugging
	public String toString() {
		if (sourceOperand1 != null) {
			if (sourceOperand2 != null) {
				if (destinationOperand != null) {
					return "PC=" + programCounter + "\t" + operationType + "\t" + sourceOperand1 + "\t" + sourceOperand2 + "\t" + destinationOperand + "\n";
				} else {
					return "PC=" + programCounter + "\t" + operationType + "\t" + sourceOperand1 + "\t" + sourceOperand2 + "\tnull" + "\n";
				}
			} else {
				if (destinationOperand != null) {
					return "PC=" + programCounter + "\t" + operationType + "\t" + sourceOperand1 + "\tnull" + "\t" + destinationOperand + "\n";
				} else {
					return "PC=" + programCounter + "\t" + operationType + "\t" + sourceOperand1 + "\tnull" + "\tnull" + "\n";
				}
			}
		} else {
			if (sourceOperand2 != null) {
				if (destinationOperand != null) {
					return "PC=" + programCounter + "\t" + operationType + "\tnull" + "\t" + sourceOperand2 + "\t" + destinationOperand + "\n";
				} else {
					return "PC=" + programCounter + "\t" + operationType + "\tnull" + "\t" + sourceOperand2 + "\tnull" + "\n";
				}
			} else {
				if (destinationOperand != null) {
					return "PC=" + programCounter + "\t" + operationType + "\tnull" + "\tnull" + "\t" + destinationOperand + "\n";
				} else {
					return "PC=" + programCounter + "\t" + operationType + "\tnull" + "\tnull" + "\tnull" + "\n";
				}
			}
		}
	}
}

